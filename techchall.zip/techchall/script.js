const send = document.querySelector(".send");
send.addEventListener("click", (e) => {
  window.alert("Votre message est soumis.");
});
